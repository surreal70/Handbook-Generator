<!--
Template: IT-Betriebshandbuch
Hinweis: Platzhalter sind mit [TODO] gekennzeichnet. Bitte anpassen.
Versionierung: Nutzen Sie vorzugsweise SemVer oder Ihr internes Schema.
-->

# Bekannte Probleme und FAQ

## Bekannte Probleme (Known Errors)
| Problem | Symptom | Ursache | Workaround | Fix/Status | Link |
|---|---|---|---|---|---|
| [TODO] | [TODO] | [TODO] | [TODO] | [TODO] | [TODO] |

## Häufige Fragen (FAQ)
### Wie erkenne ich, ob der Service gesund ist?
[TODO]

### Was tun bei Timeouts?
[TODO]

### Wie finde ich die relevante Korrelations-ID?
[TODO]
