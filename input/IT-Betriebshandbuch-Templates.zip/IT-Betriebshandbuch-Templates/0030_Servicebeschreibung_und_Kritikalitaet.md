<!--
Template: IT-Betriebshandbuch
Hinweis: Platzhalter sind mit [TODO] gekennzeichnet. Bitte anpassen.
Versionierung: Nutzen Sie vorzugsweise SemVer oder Ihr internes Schema.
-->

# Servicebeschreibung und Kritikalität

## Servicebeschreibung
- **Service-Name:** [TODO]
- **Kurzbeschreibung:** [TODO] (1–3 Sätze)
- **Geschäftszweck:** [TODO]
- **Kunden/Nutzergruppen:** [TODO]
- **Abhängigkeiten zu anderen Services:** [TODO]

## Kritikalität & Schutzbedarf
| Dimension | Einstufung | Begründung |
|---|---|---|
| Verfügbarkeit | ☐ niedrig ☐ mittel ☐ hoch | [TODO] |
| Integrität | ☐ niedrig ☐ mittel ☐ hoch | [TODO] |
| Vertraulichkeit | ☐ niedrig ☐ mittel ☐ hoch | [TODO] |
| Nachvollziehbarkeit | ☐ niedrig ☐ mittel ☐ hoch | [TODO] |

## Servicezeiten und Betriebsfenster
- **Servicezeit:** [TODO] (z. B. 24/7 oder Mo–Fr 08:00–18:00 CET)
- **Wartungsfenster:** [TODO] (Tag/Uhrzeit, Frequenz)
- **Geplante Downtimes Kommunikation:** [TODO]

## SLA/SLO (falls vorhanden)
| Kennzahl | Zielwert | Messmethode | Quelle |
|---|---:|---|---|
| Verfügbarkeit | [TODO]% | [TODO] | [TODO] |
| MTTR | [TODO] | [TODO] | [TODO] |
| Antwortzeit | [TODO] | [TODO] | [TODO] |
