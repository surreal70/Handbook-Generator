<!--
Template: IT-Betriebshandbuch
Hinweis: Platzhalter sind mit [TODO] gekennzeichnet. Bitte anpassen.
Versionierung: Nutzen Sie vorzugsweise SemVer oder Ihr internes Schema.
-->

# Change- und Release-Management

## Change-Kategorien
| Typ | Beispiel | Genehmigung | Vorlauf |
|---|---|---|---|
| Standard | Routine, risikoarm | vordefiniert | [TODO] |
| Normal | geplant, bewertet | CAB/Owner | [TODO] |
| Emergency | zur Wiederherstellung | Emergency CAB | sofort |

## Change-Request Pflichtangaben
- Beschreibung & Motivation: [TODO]
- Betroffene Komponenten/Services: [TODO]
- Risikoabschätzung: [TODO]
- Rollback-Plan: [TODO]
- Testnachweis: [TODO]
- Kommunikationsplan: [TODO]

## Release-Prozess (Beispiel)
1. Code Freeze (optional)
2. Build/Artefakt-Erstellung
3. Deployment Staging
4. Smoke Tests
5. Deployment PROD
6. Monitoring & Go/No-Go
7. Abschlussdokumentation

## Release-Kalender
- Link/Tool: [TODO]
