<!--
Template: IT-Betriebshandbuch
Hinweis: Platzhalter sind mit [TODO] gekennzeichnet. Bitte anpassen.
Versionierung: Nutzen Sie vorzugsweise SemVer oder Ihr internes Schema.
-->

# Runbooks – Standardoperationen

## Liste der Runbooks
| Runbook | Zweck | Trigger | Link |
|---|---|---|---|
| Neustart Service | Wiederherstellung | Healthcheck fail | [TODO] |
| Skalierung | Kapazität erhöhen | CPU > Schwelle | [TODO] |
| Zertifikatswechsel | TLS Renewal | Ablaufdatum | [TODO] |

## Runbook-Template (pro Runbook)
### Zweck
[TODO]

### Voraussetzungen
- Rechte/Rollen: [TODO]
- Wartungsfenster nötig: ☐ ja ☐ nein

### Schritte
1. [TODO]
2. [TODO]

### Validierung
- [TODO]

### Rollback
- [TODO]

### Risiken
- [TODO]
