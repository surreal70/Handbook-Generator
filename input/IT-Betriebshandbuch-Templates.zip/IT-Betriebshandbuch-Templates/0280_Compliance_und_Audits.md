<!--
Template: IT-Betriebshandbuch
Hinweis: Platzhalter sind mit [TODO] gekennzeichnet. Bitte anpassen.
Versionierung: Nutzen Sie vorzugsweise SemVer oder Ihr internes Schema.
-->

# Compliance und Audits

## Relevante Standards/Anforderungen
- ☐ ISO 27001
- ☐ SOC 2
- ☐ BSI IT-Grundschutz
- ☐ PCI DSS
- ☐ Sonstiges: [TODO]

## Nachweise (Evidence)
| Anforderung | Nachweis | Ablage/Link | Owner | Aktualität |
|---|---|---|---|---|
| [TODO] | [TODO] | [TODO] | [TODO] | [TODO] |

## Audit-Plan
- Interne Audits: [TODO]
- Externe Audits: [TODO]
- Verantwortlichkeiten: [TODO]
