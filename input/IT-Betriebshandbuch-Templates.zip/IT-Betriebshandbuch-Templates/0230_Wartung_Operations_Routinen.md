<!--
Template: IT-Betriebshandbuch
Hinweis: Platzhalter sind mit [TODO] gekennzeichnet. Bitte anpassen.
Versionierung: Nutzen Sie vorzugsweise SemVer oder Ihr internes Schema.
-->

# Wartung und Operations-Routinen

## Regelmäßige Tätigkeiten
| Frequenz | Tätigkeit | Beschreibung | Tooling | Nachweis |
|---|---|---|---|---|
| täglich | Health Checks | [TODO] | [TODO] | [TODO] |
| wöchentlich | Log-Review | [TODO] | [TODO] | [TODO] |
| monatlich | Patch Review | [TODO] | [TODO] | [TODO] |

## Housekeeping
- Alte Artefakte löschen: [TODO]
- DB Maintenance (Vacuum/Reindex/etc.): [TODO]
- Zertifikate prüfen/rotieren: [TODO]

## Betriebsjournale
- Wo werden Betriebsnotizen/Schichtübergaben dokumentiert? [TODO]
