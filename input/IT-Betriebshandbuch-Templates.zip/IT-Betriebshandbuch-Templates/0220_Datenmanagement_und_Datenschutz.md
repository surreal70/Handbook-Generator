<!--
Template: IT-Betriebshandbuch
Hinweis: Platzhalter sind mit [TODO] gekennzeichnet. Bitte anpassen.
Versionierung: Nutzen Sie vorzugsweise SemVer oder Ihr internes Schema.
-->

# Datenmanagement und Datenschutz

## Datenklassifikation
| Datentyp | Klassifikation | Beispiele | Schutzmaßnahmen |
|---|---|---|---|
| [TODO] | ☐ öffentlich ☐ intern ☐ vertraulich | [TODO] | [TODO] |

## DSGVO/Datenschutz (falls anwendbar)
- Verantwortlicher (Controller): [TODO]
- Auftragsverarbeiter (Processor): [TODO]
- TOMs (Technische/Organisatorische Maßnahmen): [TODO]
- Löschkonzept & Aufbewahrung: [TODO]

## Datenflüsse und -speicherung
- Wo werden Daten gespeichert? [TODO]
- Replikation/Export: [TODO]
- Datenminimierung: [TODO]
