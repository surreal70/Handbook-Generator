<!--
Template: IT-Betriebshandbuch
Hinweis: Platzhalter sind mit [TODO] gekennzeichnet. Bitte anpassen.
Versionierung: Nutzen Sie vorzugsweise SemVer oder Ihr internes Schema.
-->

# Verfügbarkeit und Service Level

## Ziele und Kennzahlen
| Kennzahl | Definition | Zielwert | Quelle |
|---|---|---:|---|
| Availability | Uptime in % | [TODO]% | [TODO] |
| MTTR | Mean Time To Repair | [TODO] | [TODO] |
| MTTD | Mean Time To Detect | [TODO] | [TODO] |

## Wartungsfenster
- Standard: [TODO]
- Notfallwartungen: Prozess [TODO]

## Redundanzkonzept
- Komponenten redundant: [TODO]
- Single Points of Failure: [TODO]
- Maßnahmen: [TODO]
