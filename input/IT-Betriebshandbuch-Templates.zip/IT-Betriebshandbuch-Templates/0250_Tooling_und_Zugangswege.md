<!--
Template: IT-Betriebshandbuch
Hinweis: Platzhalter sind mit [TODO] gekennzeichnet. Bitte anpassen.
Versionierung: Nutzen Sie vorzugsweise SemVer oder Ihr internes Schema.
-->

# Tooling und Zugangswege

## Überblick
| Zweck | Tool | URL | Zugang | Bemerkungen |
|---|---|---|---|---|
| Monitoring | [TODO] | [TODO] | SSO/RBAC | [TODO] |
| Tickets | [TODO] | [TODO] | [TODO] | [TODO] |
| CI/CD | [TODO] | [TODO] | [TODO] | [TODO] |
| Passwort-Tresor | [TODO] | [TODO] | [TODO] | [TODO] |

## Administrationszugänge
- Jump Host/Bastion: [TODO]
- VPN: [TODO]
- Break-Glass: siehe Access-Template

## Betriebsrelevante Repositories
- IaC Repo: [TODO]
- App Repo: [TODO]
- Dokumentation: [TODO]
