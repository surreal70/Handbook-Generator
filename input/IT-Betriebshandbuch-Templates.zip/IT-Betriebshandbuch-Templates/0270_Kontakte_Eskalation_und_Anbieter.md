<!--
Template: IT-Betriebshandbuch
Hinweis: Platzhalter sind mit [TODO] gekennzeichnet. Bitte anpassen.
Versionierung: Nutzen Sie vorzugsweise SemVer oder Ihr internes Schema.
-->

# Kontakte, Eskalation und Anbieter

## Eskalationsmatrix
| Stufe | Auslöser | Ansprechpartner | Kanal | Reaktionszeit |
|---|---|---|---|---:|
| 1 | SEV3 | Ops On-Call | [TODO] | [TODO] |
| 2 | SEV2 | Service Owner | [TODO] | [TODO] |
| 3 | SEV1/Major | Management/Crisis Team | [TODO] | [TODO] |

## Anbieter & Verträge
| Anbieter | Leistung | Vertrag/SLA | Support-Kontakt | Support-Zeiten |
|---|---|---|---|---|
| [TODO] | [TODO] | [TODO] | [TODO] | [TODO] |

## Statuspage & Kommunikationskanäle
- Statuspage: [TODO]
- Kundenkommunikation: [TODO]
- Interne Kommunikation: [TODO]
