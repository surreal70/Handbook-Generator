# ISMS-Governance: Rollen und Verantwortlichkeiten

**Dokument-ID:** 0040  
**Dokumenttyp:** ISMS-Grundlagendokument  
**Standard-Referenz:** ISO/IEC 27001:2022 (inkl. Amd 1:2024, sofern relevant)  
**Owner:** [TODO]  
**Version:** 0.1 (Entwurf)  
**Status:** Entwurf / In Review / Freigegeben  
**Klassifizierung:** Intern / Vertraulich / Streng vertraulich  
**Letzte Aktualisierung:** 2026-01-31  
**Nächster Review:** [TODO] (z. B. jährlich oder anlassbezogen)

---

> **Hinweis:** Template. Ersetze `[TODO]`-Platzhalter und entferne nicht zutreffende Abschnitte.  
> **Wichtig:** Dieses Dokument paraphrasiert keine Normtexte, sondern bietet praxisübliche Struktur und Inhalte.

## 1. Governance-Struktur
- ISMS-Owner / Top Management Sponsor: [TODO]
- ISMS-Manager: [TODO]
- Informationssicherheitsgremium (z. B. Steering Committee): [TODO]
- Schnittstellen: ITSM, Datenschutz, Risk, BCM, Internal Audit: [TODO]

## 2. Rollenbeschreibung (Beispiele)
### 2.1 ISMS-Manager
- Aufgaben: [TODO]
- Berichtslinie: [TODO]

### 2.2 Asset Owner / Process Owner
- Aufgaben: [TODO]

### 2.3 Control Owner
- Aufgaben: [TODO]
- Evidence-Verantwortung: [TODO]

### 2.4 Internal Audit / Compliance
- Aufgaben: [TODO]

## 3. RACI (optional)
| Aktivität | Responsible | Accountable | Consulted | Informed |
|---|---|---|---|---|
| Risikoanalyse | [TODO] | [TODO] | [TODO] | [TODO] |
| SoA Pflege | [TODO] | [TODO] | [TODO] | [TODO] |
