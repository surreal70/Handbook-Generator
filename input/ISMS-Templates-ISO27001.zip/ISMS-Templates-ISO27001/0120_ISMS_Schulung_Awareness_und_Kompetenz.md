# Schulung, Awareness und Kompetenz

**Dokument-ID:** 0120  
**Dokumenttyp:** ISMS-Grundlagendokument  
**Standard-Referenz:** ISO/IEC 27001:2022 (inkl. Amd 1:2024, sofern relevant)  
**Owner:** [TODO]  
**Version:** 0.1 (Entwurf)  
**Status:** Entwurf / In Review / Freigegeben  
**Klassifizierung:** Intern / Vertraulich / Streng vertraulich  
**Letzte Aktualisierung:** 2026-01-31  
**Nächster Review:** [TODO] (z. B. jährlich oder anlassbezogen)

---

> **Hinweis:** Template. Ersetze `[TODO]`-Platzhalter und entferne nicht zutreffende Abschnitte.  
> **Wichtig:** Dieses Dokument paraphrasiert keine Normtexte, sondern bietet praxisübliche Struktur und Inhalte.

## 1. Zielgruppen
- Alle Mitarbeitenden
- Admins/Privileged Users
- Entwickler/DevOps
- Dienstleister

## 2. Schulungsplan
| Training | Zielgruppe | Frequenz | Inhalt | Nachweis | Owner |
|---|---|---|---|---|---|
| ISMS-Grundlagen | Alle | jährlich | [TODO] | LMS/Teilnahmeliste | [TODO] |

## 3. Wirksamkeitsprüfung
- Quiz/Phishing-Simulation/Feedback: [TODO]
