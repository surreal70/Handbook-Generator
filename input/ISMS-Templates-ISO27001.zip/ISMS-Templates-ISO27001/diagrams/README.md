# diagrams/

Lege hier Diagramme ab, z. B.
- ISMS-Organigramm / Governance
- Scope-Diagramm
- Datenflüsse / Schnittstellen
- Netzwerk-Segmentierung (High-Level)

Empfohlene Formate: PNG/SVG/PDF.
