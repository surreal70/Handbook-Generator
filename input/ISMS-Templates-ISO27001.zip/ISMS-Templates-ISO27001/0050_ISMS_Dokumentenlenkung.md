# Dokumentenlenkung / Dokumentierte Information

**Dokument-ID:** 0050  
**Dokumenttyp:** ISMS-Grundlagendokument  
**Standard-Referenz:** ISO/IEC 27001:2022 (inkl. Amd 1:2024, sofern relevant)  
**Owner:** [TODO]  
**Version:** 0.1 (Entwurf)  
**Status:** Entwurf / In Review / Freigegeben  
**Klassifizierung:** Intern / Vertraulich / Streng vertraulich  
**Letzte Aktualisierung:** 2026-01-31  
**Nächster Review:** [TODO] (z. B. jährlich oder anlassbezogen)

---

> **Hinweis:** Template. Ersetze `[TODO]`-Platzhalter und entferne nicht zutreffende Abschnitte.  
> **Wichtig:** Dieses Dokument paraphrasiert keine Normtexte, sondern bietet praxisübliche Struktur und Inhalte.

## 1. Ablage und Zugriff
- Offizieller Ablageort: [TODO]
- Zugriffskontrolle: [TODO]
- Offline-/Notfallzugriff: [TODO]

## 2. Lebenszyklus
- Erstellung: [TODO]
- Review: [TODO] (Intervalle)
- Freigabe: [TODO]
- Veröffentlichung/Kommunikation: [TODO]
- Archivierung/Löschung: [TODO]

## 3. Versionierung
- Schema: [TODO]
- Change-Log: [TODO]

## 4. Dokumentenregister
| Dokument | ID | Owner | Status | Version | Nächster Review |
|---|---|---|---|---|---|
| ISMS-Policy | 0010 | [TODO] | [TODO] | [TODO] | [TODO] |
