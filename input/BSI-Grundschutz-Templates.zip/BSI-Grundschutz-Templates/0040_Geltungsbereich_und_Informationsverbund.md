# Geltungsbereich und Informationsverbund (Abgrenzung)

**Dokument-ID:** 0040  
**Dokumenttyp:** Grundlagendokument  
**Referenzrahmen:** BSI IT-Grundschutz (BSI Standards 200-1/200-2/200-3; je nach Bedarf)  
**Owner:** [TODO]  
**Version:** 0.1 (Entwurf)  
**Status:** Entwurf / In Review / Freigegeben  
**Klassifizierung:** Intern / Vertraulich / Streng vertraulich  
**Letzte Aktualisierung:** 2026-01-31  
**Nächster Review:** [TODO]

---

> **Hinweis:** Template. Ersetze alle `[TODO]`-Platzhalter und entferne nicht zutreffende Abschnitte.  
> **Wichtig:** Keine Normtexte/BSI-Originalformulierungen übernehmen; dieses Template dient der praktischen Dokumentation.

## 1. Scope-Definition
- Organisationseinheiten/Standorte: [TODO]
- Prozesse/Services: [TODO]
- IT/OT/Cloud: [TODO]

## 2. Abgrenzung des Informationsverbunds
- In Scope: [TODO]
- Out of Scope: [TODO] (Begründung, Risiken, Schnittstellen)

## 3. Schnittstellen und Abhängigkeiten
- Externe Dienstleister/Provider: [TODO]
- Kritische Schnittstellen: [TODO]

## 4. Diagramm
- `diagrams/informationsverbund.png` (Grenze, Hauptkomponenten)
