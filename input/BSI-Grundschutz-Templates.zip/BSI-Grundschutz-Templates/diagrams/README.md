# diagrams/

Lege hier Diagramme ab, z. B.
- Informationsverbund-Abgrenzung
- Netzplan / Zonenmodell
- Datenflüsse
- Modellierungsübersicht

Empfohlene Formate: PNG/SVG/PDF.
