# Informationssicherheitsleitlinie (Top-Management)

**Dokument-ID:** 0010  
**Dokumenttyp:** Leitlinie/Policy  
**Referenzrahmen:** BSI IT-Grundschutz (BSI Standards 200-1/200-2/200-3; je nach Bedarf)  
**Owner:** [TODO]  
**Version:** 0.1 (Entwurf)  
**Status:** Entwurf / In Review / Freigegeben  
**Klassifizierung:** Intern / Vertraulich / Streng vertraulich  
**Letzte Aktualisierung:** 2026-01-31  
**Nächster Review:** [TODO]

---

> **Hinweis:** Template. Ersetze alle `[TODO]`-Platzhalter und entferne nicht zutreffende Abschnitte.  
> **Wichtig:** Keine Normtexte/BSI-Originalformulierungen übernehmen; dieses Template dient der praktischen Dokumentation.

## 1. Zweck und Zielsetzung
- Ziel der Informationssicherheit: [TODO]
- Schutzwerte (Vertraulichkeit, Integrität, Verfügbarkeit + ggf. Authentizität/Nachvollziehbarkeit): [TODO]

## 2. Geltungsbereich
- Organisation/Standorte: [TODO]
- Informationsverbünde im Scope: [TODO]
- Ausnahmen: [TODO]

## 3. Grundsätze
- Risikobasierter Ansatz und angemessene Maßnahmen: [TODO]
- Verantwortlichkeiten und Ressourcen: [TODO]
- Kontinuierliche Verbesserung: [TODO]
- Verpflichtung zur Einhaltung von Anforderungen (intern/extern): [TODO]

## 4. Verantwortlichkeiten
- Top-Management: [TODO]
- ISB (Informationssicherheitsbeauftragte/r): [TODO]
- Informationsverbund-Verantwortliche: [TODO]

## 5. Kommunikation und Durchsetzung
- Kommunikation der Leitlinie: [TODO]
- Konsequenzen bei Verstößen: [TODO]

## 6. Freigabe
| Rolle | Name | Datum | Freigabe |
|---|---|---|---|
| Geschäftsführung | [TODO] | [TODO] | [TODO] |
| ISB | [TODO] | [TODO] | [TODO] |
