# Umsetzungssteuerung, Reporting und KPIs

**Dokument-ID:** 0110  
**Dokumenttyp:** Steuerungsdokument  
**Referenzrahmen:** BSI IT-Grundschutz (BSI Standards 200-1/200-2/200-3; je nach Bedarf)  
**Owner:** [TODO]  
**Version:** 0.1 (Entwurf)  
**Status:** Entwurf / In Review / Freigegeben  
**Klassifizierung:** Intern / Vertraulich / Streng vertraulich  
**Letzte Aktualisierung:** 2026-01-31  
**Nächster Review:** [TODO]

---

> **Hinweis:** Template. Ersetze alle `[TODO]`-Platzhalter und entferne nicht zutreffende Abschnitte.  
> **Wichtig:** Keine Normtexte/BSI-Originalformulierungen übernehmen; dieses Template dient der praktischen Dokumentation.

## 1. Steuerungsmodell
- Regeltermine (Steering, Arbeitsgruppen): [TODO]
- Reporting-Kanal: [TODO]

## 2. KPIs (Beispiele)
| KPI | Definition | Ziel | Quelle | Frequenz | Owner |
|---|---|---|---|---|---|
| Umsetzung Maßnahmenplan | % erledigt vs. geplant | [TODO] | Ticketing/GRC | monatlich | [TODO] |
| Patch-Compliance | % Systeme im Ziel | [TODO] | Scanner/MDM | monatlich | [TODO] |
| Backup-Testquote | % erfolgreiche Restore-Tests | [TODO] | Reports | quartalsweise | [TODO] |

## 3. Eskalationsregeln
- Wenn KPI < Ziel für [TODO] Monate: Eskalation an [TODO]
