# Anhang: Begriffe und Abkürzungen

**Dokument-ID:** 0740  
**Dokumenttyp:** Anhang  
**Referenzrahmen:** BSI IT-Grundschutz (BSI Standards 200-1/200-2/200-3; je nach Bedarf)  
**Owner:** [TODO]  
**Version:** 0.1 (Entwurf)  
**Status:** Entwurf / In Review / Freigegeben  
**Klassifizierung:** Intern / Vertraulich / Streng vertraulich  
**Letzte Aktualisierung:** 2026-01-31  
**Nächster Review:** [TODO]

---

> **Hinweis:** Template. Ersetze alle `[TODO]`-Platzhalter und entferne nicht zutreffende Abschnitte.  
> **Wichtig:** Keine Normtexte/BSI-Originalformulierungen übernehmen; dieses Template dient der praktischen Dokumentation.

## Begriffe/Abkürzungen (Beispiele)
- **ISB:** Informationssicherheitsbeauftragte/r
- **ISMS:** Informationssicherheitsmanagementsystem
- **Informationsverbund:** Abgegrenzte Menge aus Prozessen, Informationen, IT, Personen, Räumen
- **C/I/A:** Vertraulichkeit/Integrität/Verfügbarkeit

Ergänzen: [TODO]
