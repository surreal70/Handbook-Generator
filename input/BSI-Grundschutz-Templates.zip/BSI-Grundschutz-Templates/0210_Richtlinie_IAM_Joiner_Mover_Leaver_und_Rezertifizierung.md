# Richtlinie IAM Joiner Mover Leaver und Rezertifizierung

**Dokument-ID:** 0210  
**Dokumenttyp:** Richtlinie/Standard (konkret)  
**Referenzrahmen:** BSI IT-Grundschutz (BSI Standards 200-1/200-2/200-3; je nach Bedarf)  
**Owner:** [TODO]  
**Version:** 0.1 (Entwurf)  
**Status:** Entwurf / In Review / Freigegeben  
**Klassifizierung:** Intern / Vertraulich / Streng vertraulich  
**Letzte Aktualisierung:** 2026-01-31  
**Nächster Review:** [TODO]

---

> **Hinweis:** Template. Ersetze alle `[TODO]`-Platzhalter und entferne nicht zutreffende Abschnitte.  
> **Wichtig:** Keine Normtexte/BSI-Originalformulierungen übernehmen; dieses Template dient der praktischen Dokumentation.

## 1. Zweck und Bezug
- Konkretisiert Policy: [TODO]
- Ziel: [TODO]

## 2. Geltungsbereich
- Systeme/Plattformen: [TODO]
- Zielgruppen: [TODO]

## 3. Mindestanforderungen (MUSS)
- [TODO]
- [TODO]

## 4. Empfohlene Anforderungen (SOLL)
- [TODO]

## 5. Prozess
- Antrag/Genehmigung/Umsetzung/Review: [TODO]
- Tooling: [TODO]

## 6. Nachweise (Evidence)
- [TODO]

## 7. Ausnahmen
- Verweis auf Ausnahmenprozess: [TODO]
