# Managementbewertung (Management Review) – Template

**Dokument-ID:** 0620  
**Dokumenttyp:** Nachweis/Template  
**Referenzrahmen:** BSI IT-Grundschutz (BSI Standards 200-1/200-2/200-3; je nach Bedarf)  
**Owner:** [TODO]  
**Version:** 0.1 (Entwurf)  
**Status:** Entwurf / In Review / Freigegeben  
**Klassifizierung:** Intern / Vertraulich / Streng vertraulich  
**Letzte Aktualisierung:** 2026-01-31  
**Nächster Review:** [TODO]

---

> **Hinweis:** Template. Ersetze alle `[TODO]`-Platzhalter und entferne nicht zutreffende Abschnitte.  
> **Wichtig:** Keine Normtexte/BSI-Originalformulierungen übernehmen; dieses Template dient der praktischen Dokumentation.

## 1. Teilnehmer, Zeitraum, Scope
- Datum: [TODO]
- Teilnehmer: [TODO]
- Informationsverbund(e): [TODO]

## 2. Inputs
- Status Maßnahmenplan
- Ergebnisse Audits/Checks
- Sicherheitsvorfälle und Lessons Learned
- Änderungen im Kontext (Technik, Orga, Lieferanten, Recht)
- Risikolage / Top-Risiken

## 3. Outputs/Entscheidungen
- Anpassung Leitlinie/Ziele: [TODO]
- Ressourcen/Investitionen: [TODO]
- Risikoakzeptanzen: [TODO]
- Verbesserungsmaßnahmen: [TODO]
