# Schulung und Awareness – Programm

**Dokument-ID:** 0600  
**Dokumenttyp:** Programm  
**Referenzrahmen:** BSI IT-Grundschutz (BSI Standards 200-1/200-2/200-3; je nach Bedarf)  
**Owner:** [TODO]  
**Version:** 0.1 (Entwurf)  
**Status:** Entwurf / In Review / Freigegeben  
**Klassifizierung:** Intern / Vertraulich / Streng vertraulich  
**Letzte Aktualisierung:** 2026-01-31  
**Nächster Review:** [TODO]

---

> **Hinweis:** Template. Ersetze alle `[TODO]`-Platzhalter und entferne nicht zutreffende Abschnitte.  
> **Wichtig:** Keine Normtexte/BSI-Originalformulierungen übernehmen; dieses Template dient der praktischen Dokumentation.

## 1. Zielgruppen
- Alle Mitarbeitenden: [TODO]
- Admins/Privileged: [TODO]
- Entwickler: [TODO]
- Dienstleister: [TODO]

## 2. Schulungskatalog
| Training | Zielgruppe | Frequenz | Inhalte | Nachweis | Owner |
|---|---|---|---|---|---|
| Grundlagentraining IS | Alle | jährlich | [TODO] | LMS/Teilnahmeliste | [TODO] |

## 3. Wirksamkeitsmessung
- Quiz/Simulationen/Feedback: [TODO]
- KPI: [TODO]
