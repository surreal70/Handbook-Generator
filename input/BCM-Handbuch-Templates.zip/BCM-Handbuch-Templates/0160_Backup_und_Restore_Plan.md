# Backup- und Restore-Plan

**Dokument-ID:** 0160  
**Owner:** [TODO]  
**Version:** 0.1 (Entwurf)  
**Status:** Entwurf / In Review / Freigegeben  
**Klassifizierung:** Intern / Vertraulich / Streng vertraulich  
**Letzte Aktualisierung:** 2026-01-31  

---

> **Hinweis:** Dieses Dokument ist ein Template. Ersetze alle `[TODO]`-Platzhalter und entferne nicht zutreffende Abschnitte.

## 1. Ziel
Sicherstellung, dass Backups den RPO-Anforderungen entsprechen und Restore-Verfahren getestet sind.

## 2. Umfang
- Systeme/Datenklassen: [TODO]
- Ausschlüsse: [TODO]

## 3. Backup-Policy
- Frequenz: [TODO]
- Aufbewahrung: [TODO]
- Verschlüsselung: [TODO]
- Immutable/air-gapped Optionen: [TODO]

## 4. Restore-Verfahren
- Verantwortliche: [TODO]
- Restore-Varianten (Datei, DB, VM, Cluster): [TODO]
- Validierung (Checksums, App-Tests): [TODO]

## 5. Restore-Tests
| System | Testart | Frequenz | Letzter Test | Ergebnis | Findings |
|---|---|---|---|---|---|
| [TODO] | [TODO] | [TODO] | [TODO] | [TODO] | [TODO] |
