# Glossar und Abkürzungen

**Dokument-ID:** 0290  
**Owner:** [TODO]  
**Version:** 0.1 (Entwurf)  
**Status:** Entwurf / In Review / Freigegeben  
**Klassifizierung:** Intern / Vertraulich / Streng vertraulich  
**Letzte Aktualisierung:** 2026-01-31  

---

> **Hinweis:** Dieses Dokument ist ein Template. Ersetze alle `[TODO]`-Platzhalter und entferne nicht zutreffende Abschnitte.

## Glossar
- **BCM/BCMS:** Business Continuity Management / System
- **BIA:** Business Impact Analysis
- **BCP:** Business Continuity Plan (Geschäftsfortführungsplan)
- **DRP:** Disaster Recovery Plan (Wiederanlaufplan)
- **RTO:** Recovery Time Objective
- **RPO:** Recovery Point Objective
- **MTPD/MAO:** Maximum Tolerable Period of Disruption / Maximum Acceptable Outage

Ergänze organisationsspezifische Begriffe: [TODO]
