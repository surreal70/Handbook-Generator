# Business Impact Analysis (BIA) – Methodik

**Dokument-ID:** 0070  
**Owner:** [TODO]  
**Version:** 0.1 (Entwurf)  
**Status:** Entwurf / In Review / Freigegeben  
**Klassifizierung:** Intern / Vertraulich / Streng vertraulich  
**Letzte Aktualisierung:** 2026-01-31  

---

> **Hinweis:** Dieses Dokument ist ein Template. Ersetze alle `[TODO]`-Platzhalter und entferne nicht zutreffende Abschnitte.

## 1. Zweck und Output
- Ziele der BIA: [TODO]
- Erwartete Ergebnisse: RTO/RPO, MTPD/MAO, Priorisierung, Ressourcenbedarf

## 2. Vorgehen
- Workshops/Interviews: [TODO]
- Datenquellen: [TODO]
- Review- und Validierungsschritte: [TODO]

## 3. Bewertungsdimensionen (Beispiele)
- Finanziell (Umsatzverlust, Vertragsstrafen): [TODO]
- Operativ (Durchsatz, Rückstau, Qualität): [TODO]
- Recht/Regulatorik: [TODO]
- Sicherheit (Personen-/Anlagensicherheit): [TODO]
- Reputation: [TODO]

## 4. Zeitabhängigkeit
- Impact nach Zeitfenstern (z. B. 0–4h, 4–24h, 1–3d, >3d): [TODO]

## 5. Ergebnisfreigabe
- Verantwortliche für Abnahme (Fachbereich/Management): [TODO]
