# Lieferanten und Drittparteien – Kontinuität

**Dokument-ID:** 0180  
**Owner:** [TODO]  
**Version:** 0.1 (Entwurf)  
**Status:** Entwurf / In Review / Freigegeben  
**Klassifizierung:** Intern / Vertraulich / Streng vertraulich  
**Letzte Aktualisierung:** 2026-01-31  

---

> **Hinweis:** Dieses Dokument ist ein Template. Ersetze alle `[TODO]`-Platzhalter und entferne nicht zutreffende Abschnitte.

## 1. Ziel
Sicherstellen, dass kritische Lieferanten/Provider BCM-Anforderungen erfüllen.

## 2. Kritische Lieferanten
| Lieferant | Leistung | Kritikalität | SLA/Vertrag | Notfallkontakt | Nachweise (z. B. SOC/ISO) |
|---|---|---|---|---|---|
| [TODO] | [TODO] | H | [TODO] | [TODO] | [TODO] |

## 3. Anforderungen
- Mindestanforderungen (RTO/RPO, DR, Kommunikation, Tests): [TODO]
- Auslagerungs-/Outsourcing-Richtlinien: [TODO]

## 4. Überwachung und Review
- Review-Frequenz: [TODO]
- Audit-Rechte / Reports: [TODO]
