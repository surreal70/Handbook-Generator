# Schulungen und Sensibilisierung

**Dokument-ID:** 0260  
**Owner:** [TODO]  
**Version:** 0.1 (Entwurf)  
**Status:** Entwurf / In Review / Freigegeben  
**Klassifizierung:** Intern / Vertraulich / Streng vertraulich  
**Letzte Aktualisierung:** 2026-01-31  

---

> **Hinweis:** Dieses Dokument ist ein Template. Ersetze alle `[TODO]`-Platzhalter und entferne nicht zutreffende Abschnitte.

## 1. Zielgruppen
- Krisenstab
- IT-DR-Teams
- Fachbereiche (BCP)
- Externe Dienstleister

## 2. Schulungskatalog
| Training | Zielgruppe | Frequenz | Inhalt | Owner | Nachweis |
|---|---|---|---|---|---|
| BCM-Einführung | Alle | jährlich | [TODO] | [TODO] | [TODO] |

## 3. Onboarding
- Neue Rollen im Krisenstab: [TODO]
- Zugriff auf BCM-Dokumente: [TODO]
