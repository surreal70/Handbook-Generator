# Pflege, Review und KPIs

**Dokument-ID:** 0250  
**Owner:** [TODO]  
**Version:** 0.1 (Entwurf)  
**Status:** Entwurf / In Review / Freigegeben  
**Klassifizierung:** Intern / Vertraulich / Streng vertraulich  
**Letzte Aktualisierung:** 2026-01-31  

---

> **Hinweis:** Dieses Dokument ist ein Template. Ersetze alle `[TODO]`-Platzhalter und entferne nicht zutreffende Abschnitte.

## 1. Review-Zyklen
- Handbuch: [TODO] (z. B. jährlich)
- Kontaktlisten: [TODO] (z. B. monatlich)
- Kritische Runbooks: [TODO] (z. B. quartalsweise)
- Lieferanten: [TODO]

## 2. Auslöser für anlassbezogene Updates
- Systemänderungen (Major Releases): [TODO]
- Orga-Änderungen (Rollen/Teams): [TODO]
- Findings aus Tests/Incidents: [TODO]

## 3. KPIs/Metriken (Beispiele)
- Anteil kritischer Services mit aktuellem DRP: [TODO]%
- Restore-Testquote (erfolgreich): [TODO]%
- Durchschnittliche Zeit bis Krisenaktivierung: [TODO]

## 4. Reporting
- Empfänger: [TODO]
- Frequenz: [TODO]
- Format: [TODO]
