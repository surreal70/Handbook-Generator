# diagrams/

Lege hier Diagramme ab, z. B.
- Organigramm Notfallorganisation
- Aktivierungs-/Entscheidungsbaum
- Service-/Systemabhängigkeiten
- Wiederanlauf-Reihenfolgen

Empfohlene Formate: PNG/SVG/PDF (je nach Tooling).
