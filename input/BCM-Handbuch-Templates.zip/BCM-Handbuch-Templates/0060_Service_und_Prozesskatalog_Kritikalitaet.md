# Service- und Prozesskatalog mit Kritikalität

**Dokument-ID:** 0060  
**Owner:** [TODO]  
**Version:** 0.1 (Entwurf)  
**Status:** Entwurf / In Review / Freigegeben  
**Klassifizierung:** Intern / Vertraulich / Streng vertraulich  
**Letzte Aktualisierung:** 2026-01-31  

---

> **Hinweis:** Dieses Dokument ist ein Template. Ersetze alle `[TODO]`-Platzhalter und entferne nicht zutreffende Abschnitte.

## 1. Ziel
Dokumentiere die im BCM betrachteten Services/Prozesse inkl. Kritikalität und Ownern als Grundlage für BIA, Strategien und Pläne.

## 2. Katalog
| Service/Prozess | Owner | Kritikalität (H/M/L) | Beschreibung | Abhängigkeiten (Top 5) | Kunden/Stakeholder |
|---|---|---|---|---|---|
| [TODO] | [TODO] | H | [TODO] | [TODO] | [TODO] |

## 3. Kriterien zur Kritikalität
- Kriterien (z. B. Umsatz, Recht, Sicherheit, Reputation, Kundenimpact): [TODO]
- Bewertungslogik / Scoring: [TODO]
