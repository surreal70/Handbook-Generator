# BCP – Geschäftsfortführungsplan (Template pro Prozess/Service)

**Dokument-ID:** 0140  
**Owner:** [TODO]  
**Version:** 0.1 (Entwurf)  
**Status:** Entwurf / In Review / Freigegeben  
**Klassifizierung:** Intern / Vertraulich / Streng vertraulich  
**Letzte Aktualisierung:** 2026-01-31  

---

> **Hinweis:** Dieses Dokument ist ein Template. Ersetze alle `[TODO]`-Platzhalter und entferne nicht zutreffende Abschnitte.

## 1. Prozess/Service
- Name: [TODO]
- Owner: [TODO]
- Kritikalität: [TODO]
- RTO/RPO/MTPD: [TODO]

## 2. Normalbetrieb (Kurzbeschreibung)
- Eingaben/Outputs: [TODO]
- Systeme/Tools: [TODO]
- Schlüsselrollen: [TODO]

## 3. Minimalbetrieb (MVS) / Prioritäten
- Welche Teilfunktionen müssen zwingend laufen? [TODO]
- Welche können warten? [TODO]

## 4. Workarounds / Manuelle Verfahren
- Schrittfolge: [TODO]
- Benötigte Ressourcen (Formulare, Zugänge, Datenexporte): [TODO]
- Risiken/Fehlerquellen: [TODO]

## 5. Abhängigkeiten
- IT-Systeme: [TODO]
- Lieferanten: [TODO]
- Standorte/Facilities: [TODO]

## 6. Aktivierung und Ablauf
- Aktivierungsentscheidung durch: [TODO]
- Checkliste: [TODO]
- Kommunikation an Stakeholder: [TODO]

## 7. Rückkehr in Normalbetrieb
- Kriterien: [TODO]
- Datenabgleich/Nacharbeiten: [TODO]
