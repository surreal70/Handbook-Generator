# BIA – Ergebnisse und Zielwerte (RTO/RPO)

**Dokument-ID:** 0080  
**Owner:** [TODO]  
**Version:** 0.1 (Entwurf)  
**Status:** Entwurf / In Review / Freigegeben  
**Klassifizierung:** Intern / Vertraulich / Streng vertraulich  
**Letzte Aktualisierung:** 2026-01-31  

---

> **Hinweis:** Dieses Dokument ist ein Template. Ersetze alle `[TODO]`-Platzhalter und entferne nicht zutreffende Abschnitte.

## 1. Zusammenfassung
- Top-kritische Prozesse/Services: [TODO]
- Wesentliche Erkenntnisse: [TODO]

## 2. Ergebnis-Tabelle
| Service/Prozess | Kritikalität | MTPD/MAO | RTO | RPO | Manuelle Workarounds möglich? | Bemerkungen |
|---|---|---|---|---|---|---|
| [TODO] | H | [TODO] | [TODO] | [TODO] | Ja/Nein | [TODO] |

## 3. Abhängigkeiten pro kritischem Prozess
- Prozess/Service: [TODO]
  - People: [TODO]
  - Facilities: [TODO]
  - IT-Systeme: [TODO]
  - Daten: [TODO]
  - Lieferanten: [TODO]

## 4. Offene Punkte / Maßnahmen
| Maßnahme | Owner | Priorität | Fällig | Status |
|---|---|---|---|---|
| [TODO] | [TODO] | Hoch/Mittel/Niedrig | [TODO] | [TODO] |
