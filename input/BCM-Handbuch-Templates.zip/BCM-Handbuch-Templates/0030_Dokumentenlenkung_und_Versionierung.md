# Dokumentenlenkung und Versionierung

**Dokument-ID:** 0030  
**Owner:** [TODO]  
**Version:** 0.1 (Entwurf)  
**Status:** Entwurf / In Review / Freigegeben  
**Klassifizierung:** Intern / Vertraulich / Streng vertraulich  
**Letzte Aktualisierung:** 2026-01-31  

---

> **Hinweis:** Dieses Dokument ist ein Template. Ersetze alle `[TODO]`-Platzhalter und entferne nicht zutreffende Abschnitte.

## 1. Dokumentenlandkarte
- Welche BCM-Dokumente existieren? (Handbuch, Pläne, Runbooks, Kontaktlisten, Checklisten)
- Wo sind sie abgelegt (System/Ort)? [TODO]
- Offline-Verfügbarkeit / Notfallzugriff: [TODO]

## 2. Versionierung
- Schema (z. B. Major.Minor): [TODO]
- Wann wird Major/Minor erhöht? [TODO]

## 3. Freigabe- und Review-Prozess
- Ersteller: [TODO]
- Reviewer: [TODO]
- Approver: [TODO]
- Review-Intervall: z. B. halbjährlich/jährlich oder anlassbezogen

## 4. Verteiler
- Zielgruppen (Krisenstab, IT, Fachbereiche, Dienstleister): [TODO]
- Zugriff (RBAC) und Schutzbedarf: [TODO]

## 5. Änderungsprotokoll (Changelog)
| Version | Datum | Änderung | Autor | Freigabe |
|---|---|---|---|---|
| 0.1 | [TODO] | Erster Entwurf | [TODO] | [TODO] |
