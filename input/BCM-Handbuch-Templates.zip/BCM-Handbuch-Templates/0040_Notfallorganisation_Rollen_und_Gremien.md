# Notfallorganisation: Rollen und Gremien

**Dokument-ID:** 0040  
**Owner:** [TODO]  
**Version:** 0.1 (Entwurf)  
**Status:** Entwurf / In Review / Freigegeben  
**Klassifizierung:** Intern / Vertraulich / Streng vertraulich  
**Letzte Aktualisierung:** 2026-01-31  

---

> **Hinweis:** Dieses Dokument ist ein Template. Ersetze alle `[TODO]`-Platzhalter und entferne nicht zutreffende Abschnitte.

## 1. Organisationsmodell
- Notfallorganisation (Krisenstab, Lagezentrum, IT-DR-Team, Fachbereichs-BCP-Teams): [TODO]
- Organigramm (siehe `diagrams/`): [TODO]

## 2. Rollenbeschreibung (Beispiele)
### 2.1 Krisenstabsleitung
- Aufgaben: [TODO]
- Stellvertretung: [TODO]
- Entscheidungskompetenzen: [TODO]

### 2.2 BCM-Manager / BCM-Koordinator
- Aufgaben: [TODO]
- Reporting: [TODO]

### 2.3 Incident Commander / Einsatzleitung (operativ)
- Aufgaben: [TODO]
- Schnittstelle zu ITSM/Incident: [TODO]

### 2.4 Kommunikation / Sprecherrolle
- Aufgaben: [TODO]
- Freigabeprozesse: [TODO]

### 2.5 IT-DR-Lead
- Aufgaben: [TODO]
- Runbooks und Wiederanlaufkoordination: [TODO]

## 3. Erreichbarkeit und Rufbereitschaft
- Bereitschaftsmodelle: [TODO]
- Eskalationszeiten: [TODO]

## 4. Vertretungsregelungen
- Stellvertreterlisten und Übergabe: [TODO]
