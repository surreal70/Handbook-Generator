# Nachbereitung / Postmortem

**Dokument-ID:** 0240  
**Owner:** [TODO]  
**Version:** 0.1 (Entwurf)  
**Status:** Entwurf / In Review / Freigegeben  
**Klassifizierung:** Intern / Vertraulich / Streng vertraulich  
**Letzte Aktualisierung:** 2026-01-31  

---

> **Hinweis:** Dieses Dokument ist ein Template. Ersetze alle `[TODO]`-Platzhalter und entferne nicht zutreffende Abschnitte.

## 1. Anlass
- Incident/Krise: [TODO]
- Zeitraum: [TODO]

## 2. Zusammenfassung (Executive Summary)
- Was ist passiert? [TODO]
- Impact (Kunden/Finanzen/Reputation): [TODO]
- Dauer: [TODO]

## 3. Root Cause & beitragende Faktoren
- Technisch: [TODO]
- Organisatorisch: [TODO]
- Extern: [TODO]

## 4. Was lief gut / Was lief schlecht
- Good: [TODO]
- Bad: [TODO]

## 5. Maßnahmenplan
| Maßnahme | Kategorie | Priorität | Owner | Fällig | Status |
|---|---|---|---|---|---|
| [TODO] | Prävention/Detektion/Recovery | Hoch | [TODO] | [TODO] | [TODO] |

## 6. BCM-Artefakte aktualisieren
- BIA/Strategie/Runbooks betroffen? [TODO]
- Dokumente angepasst am: [TODO]
