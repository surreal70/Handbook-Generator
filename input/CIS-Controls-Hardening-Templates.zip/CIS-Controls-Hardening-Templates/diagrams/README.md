# diagrams/

Lege hier Diagramme ab (optional):
- Tiering/Zone Modell
- Baseline Architektur (Config Mgmt / MDM / GPO / IaC)
- Datenflüsse (Logging, Scanning, Reporting)
